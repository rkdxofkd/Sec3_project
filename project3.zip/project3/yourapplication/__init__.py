from flask import Flask, render_template
from flask import request
import pickle
import pandas as pd
from xgboost import XGBClassifier

app = Flask(__name__)
def create_app():

  

  return app



model=None

with open('./model.pkl', 'rb') as pickle_file:
  model = pickle.load(pickle_file)


@app.route('/', methods= ['POST', 'GET'])
def index():

  return render_template('hello.html')


@app.route('/answer', methods= ['POST', 'GET'])
def answer():
  sex = request.form.get("sex")
  weight = request.form.get("weight")
  height = request.form.get("height")
  left_eye = request.form.get("left_eye")
  right_eye = request.form.get("right_eye")
  sys_pressure = request.form.get("sys_pressure")
  blood_sugar = request.form.get("blood_sugar")
  AST = request.form.get("AST")
  ALT = request.form.get("ALT")
  creatinine = request.form.get("creatinine")
  if sex =="남자":
    sex=1
  else:
    sex=2
  result = pd.DataFrame({"sex" :sex,
  "weight": float(weight), "height":float(height), 
  "left_eye":float(left_eye), "right_eye": float(right_eye),
  "sys_pressure": float(sys_pressure), "blood_sugar":float(blood_sugar),
   "AST": float(AST), "ALT": float(ALT), "creatinine":float(creatinine)}, index=[0])

  prediction = model.predict(result)

  if prediction[0] == 0:
    return render_template('answer0.html')
  elif prediction[0] == 1:
    return render_template('answer1.html')
  elif prediction[0] == 2:
    return render_template('answer2.html')
  elif prediction[0] ==3:
    return render_template('answer3.html')
  elif prediction[0] ==4:
    return render_template('answer4.html')
  elif prediction[0] ==5:
    return render_template('answer5.html')
  else :
    return render_template('answer6.html')


if __name__ == "__main__":
  app = create_app()
  app.run(debug=True)
