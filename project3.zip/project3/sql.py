import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
import pickle

data = pd.read_csv("./project.csv", encoding='utf-8')

data['nutrient']=data['nutrient'].fillna(0)

data.loc[(data['weight']/((data['height']/100)**2))>25, 'nutrient'] =1
data.loc[((data['left_eye']+data['right_eye'])/2) <0.3, 'nutrient'] =2
data.loc[data['sys_pressure']>140, 'nutrient'] = 3
data.loc[data['blood_sugar']>126, 'nutrient'] = 4
data.loc[(data['AST']>40) | (data['ALT']>40),'nutrient'] =5
data.loc[(data['sex']==1) & (data['creatinine']>1.5), 'nutrient'] = 6
data.loc[(data['sex']==2) & (data['creatinine']>1.0), 'nutrient'] = 6



target = ['nutrient']

X = data[['sex','weight','height', 'left_eye','right_eye',
 'sys_pressure', 'blood_sugar', 'AST', 'ALT', 'creatinine']]
y = data[target]

x_train, x_test,y_train,y_test = train_test_split( X, y
    , train_size=0.80, test_size=0.20, stratify=data[target], random_state=2
)
model = XGBClassifier(
learning_rate=1, random_state=0, n_estimators=8)
model.fit(x_train, y_train)


result = pd.DataFrame({"sex":1,
"weight": 123  , "height":123, 
"left_eye":123, "right_eye": 123,
"sys_pressure": 123, "blood_sugar":123,
"AST": 123, "ALT": 123, "creatinine": 123}, index=[0])


with open('model.pkl','wb') as pickle_file:
    pickle.dump(model, pickle_file)